

(function($, undefined) {
    "use strict";
	
    window.fmdita = window.fmdita || {};
    var createWizardRel = ".apps-dita-publish-createreview";
    var assigneeList = [], validateAll = null , TITLE_XPATH = '[name="title"]';
    var REVIEW_PAYLOAD_KEY = "fmdita.revert_data";

    var ui = $(window).adaptTo("foundation-ui");
	
	

    var payload = window.fmdita.payload = window.fmdita.payload || JSON.parse(decodeURIComponent(sessionStorage.getItem(REVIEW_PAYLOAD_KEY)));
    sessionStorage.removeItem(REVIEW_PAYLOAD_KEY);

    var payloadExists = payload && Array.isArray(payload.asset) && (payload.asset.length > 0)

    // Handle the add task back button
    $(document).fipo("tap.foundation-wizard-control", "click.foundation-wizard-control", ".foundation-wizard-control", function(e) {
        if ($(this).data("foundation-wizard-control-action") != "cancel") return;

        var ref = $(".urlParameters").data("ref");
        if (!ref || ref.length == 0) return;

        e.preventDefault();
        window.location = Granite.HTTP.externalize(ref);
    });

    function shouldOverrideReviewers(newAssignees, oldAsssignees){
        if(!oldAsssignees){
            return true
        }

        newAssignees = newAssignees || []
        if(oldAsssignees.length !== newAssignees.length){
            return true
        }
        var bRetVal = false
        $.each(oldAsssignees, function(idx, oItem) {
            if(!$.find(newAssignees, oItem)){
                bRetVal = true
            }
        })
        return bRetVal
    }

    function nextDuplicate(olddata, versionData){
        olddata.mapPath = getDitaMapPath()
        olddata.assignee = assigneeList
        olddata.shouldOverwrite = false
        olddata.versionData = versionData

        rh.model.publish('.d.versions.versiondata', olddata)
    }
    function readTab2Data(versionData){
        var mapPath = window.reviewPanel.getMapPath()
        var olddata = rh.model.get('.d.review.olddata')
        if(olddata){
            nextDuplicate(olddata, versionData)
        }
        else{
            var title = $('[name="title"]').val();
            var oldAssignees =  rh.model.get('.d.versions.assigneeList')
            rh.model.publish('.d.versions.assigneeList', assigneeList)
            var shouldOverwrite = true /*shouldOverrideReviewers(assigneeList, oldAssignees)*/
            rh.model.publish('.d.versions.versiondata',
                {versionData: versionData,
                mapPath: mapPath,
                assignee: assigneeList,
                reviewTitle: title,
                shouldOverwrite: shouldOverwrite})
        }
    }

    function showNoTopicError(){
        var ui = $(window).adaptTo("foundation-ui"); 
        ui.alert(Granite.I18n.get("No File Selected"), Granite.I18n.get("Please select atleast one file to revert the version."), "error");
    }

    function isNoTopicSelected(versionData){
        for(var i = 0; i < versionData.length; i++){
            if(versionData[i].review){
                return false
            }
        }
        return true
    }
    function checkNoTopic(versionData){
        if(isNoTopicSelected(versionData)){
            showNoTopicError()
            return false;
        }
        return true;
    }
    function cancelNext(){
        var $wizard = $(".foundation-wizard"),
            wizardApi = $wizard.adaptTo("foundation-wizard");
        wizardApi.prev()
    }
	
	function doRevert(fileData) {
	
		var suceessFlag = "true";
		var ajaxOptions = {
			type: 'post',
			url: '/bin/referencelistener',
			data: {
				operation: 'restoreVersion',
				_charset_: "UTF-8",
				path: fileData.path,
				version: fileData.version,
				upVersion: "false",
				revertVerComment: ""
			}
		}
		
		var jqxhr = $.ajax(ajaxOptions);
		jqxhr.done(function(html) {
		});
		jqxhr.fail(function(xhr, error, errorThrown) {
			suceessFlag = "false";
		});
		
		return suceessFlag;
	}
    function doNext(form){
		var flag = true;
		var versionData = window.reviewPanel.getVersionData()
			
		if(!checkNoTopic(versionData)){
			return;
		}

		
		for(var i = 0; i < versionData.length; i++){
            if(versionData[i].review == true){
                var revertFlag = doRevert(versionData[i]);
				if(revertFlag === "false"){
					flag = false;
				}
            }
        }
		
		if(flag == true){
			var title = $('[name="title"]').val();
			var modal = CQ.projects.modal.successTemplate.clone();
			modal.find(".coral-Modal-header h2").html(Granite.I18n.get("Success"));
			var strLocalize = Granite.I18n.get("Revert task has been completed.");
			
			modal.find(".coral-Modal-body").html(strLocalize);

			var footer = modal.find(".coral-Modal-footer");

			$('<a class="coral-Button coral-Button--primary"></a>')
				.prop("href", document.referrer)
				.text(Granite.I18n.get("Close"))
				.appendTo(footer);

			modal.appendTo("body").modal("show");
		}else {
			var ui = $(window).adaptTo("foundation-ui");
			ui.alert(Granite.I18n.get("Error"), Granite.I18n.get("Failed to revert."), "error");
		}
        
    } 
    
    function doSubmit(form) {
        var targetUrl = "/bin/publishlistener";
        if(!targetUrl){
            var ui = $(window).adaptTo("foundation-ui");
            ui.alert(Granite.I18n.get("Incomplete Form"),
                Granite.I18n.get("Enter a valid project name"),
                "error");
            return;
        }

        if (!payload && getParameterByName('taskID') === null )
        {
            var ui = $(window).adaptTo("foundation-ui");
            ui.alert(Granite.I18n.get("Incomplete Form"),
                Granite.I18n.get("Select a content payload to start review."),
                "error");
            return;
        } else {
            $("input[name='contentPath']").val(JSON.stringify(payload));
        }

        var dueDate = $($("input[name=taskDueDate]")[0]).val();
        if (dueDate == null || dueDate.length == 0)
        {
            var ui = $(window).adaptTo("foundation-ui");
            ui.alert(Granite.I18n.get("Incomplete Form"),
                Granite.I18n.get("Select due date for review."),
                "error");
            return;
        }
         var dateString= $("#aem-asset-reviewtask-datepicker .coral-InputGroup-input").val();
        var selectedTime = new Date(dateString).getTime()
        var currentTime = new Date().getTime();
        if(selectedTime < currentTime)
        {
            var ui = $(window).adaptTo("foundation-ui");
            ui.alert(Granite.I18n.get("Invalid Time Selected"),
                Granite.I18n.get("Select a time in future for ending the review."),
                "error");
            return;
        }


        var referrer;
        if(getParameterByName('taskID') !== null){
            var taskid = getParameterByName('taskID')
            referrer = '/libs/fmdita/taskdetails.html?item=' + taskid
        }
        else{
            referrer = payload.referrer
        }


        var data = $(form).find("[name!='assignee']").not("[name='review-topics']").serializeArray();

        data.push({name:'sendEmailNotification', value: 'true'});//always send email
        data.push({name: 'versions', value: JSON.stringify(window.topicReviewPanel.getVersionData())})
        var reviewAssignees = window.topicReviewPanel.assignees
        data.push({name: 'assignee', value: reviewAssignees});
        if(reviewAssignees.length == 0){
            var ui = $(window).adaptTo("foundation-ui");
            ui.alert(Granite.I18n.get("Incomplete Form"),
                Granite.I18n.get("Please assign reviewer to atleast one topic to create the review task."),
                "error");
            return;
        }    

        var allowAllReviewers =  getAllReviewersValue()
        data.push({name: 'allowAllReviewers', value: allowAllReviewers});
        var ajaxOptions = {
            type: "post",
            data: $.param(data),
            url: targetUrl
        };

        var jqxhr = $.ajax(ajaxOptions);
        jqxhr.done(function(html) {
            var title = $('[name="title"]').val();
            var modal = CQ.projects.modal.successTemplate.clone();
            modal.find(".coral-Modal-header h2").html(Granite.I18n.get("Success"));
            var strLocalize = Granite.I18n.get("Review task '{}' has been created.");
            strLocalize = strLocalize.replace("{}", title);
            modal.find(".coral-Modal-body").html(strLocalize);

            var footer = modal.find(".coral-Modal-footer");

            $('<a class="coral-Button coral-Button--primary"></a>')
                .prop("href", referrer)
                .text(Granite.I18n.get("Close"))
                .appendTo(footer);

            modal.appendTo("body").modal("show");
        });
        jqxhr.fail(function(xhr, error, errorThrown) {
            var ui = $(window).adaptTo("foundation-ui");
            ui.alert(Granite.I18n.get("Error"), Granite.I18n.get("Failed to start review."), "error");
            //window.location.href = document.referrer;
        });
    }

    function hideDitamapChooser(){
        $('#ditamapbrowser').parent().hide()
    }

    function setDitamapPath(path){
        var $el = $('#ditamapbrowser')
        $el.find('input').val(path)
    }
    function getDitaMapPath(){
        var $el = $('#ditamapbrowser')
        return $el.find('input').val()
    }
    function getAllReviewersValue(){
        return ($('coral-checkbox[name="allreviewers"] input:checked').val() === "true")? true: false
    }
    function publishOldData(resultJson){
        rh.model.publish('.d.review.olddata', {oldDitamap: resultJson.ditamap, oldVersionData : JSON.parse(resultJson.versionJson)})
    }
    function doPage1Next($form){
        var ditamap = getDitaMapPath()
        var base = rh._.parentPath(ditamap)
        payload = {asset: [ditamap], base: base}
        rh.model.publish(".d.versions.payload", payload);
    }

    function registerOnPage1Next(){
        $(".create-review-button").click(function(e) {
            doPage1Next()
        })
    }

    var clearAllUsers = null;


    function initValidation() {
        var DISABLE_CLASS = "button-disabled";
        var titleUI = $(".review-title"), projectUI = $(".review-project-path");
        var create = $(".foundation-wizard-control.create-review-button"), dueDateUI = $(".review-due-date");
        create.addClass(DISABLE_CLASS);
        validateAll = function() {
            var bValid = true, dueDate = moment($('[name="taskDueDate"]').val());
            var title = titleUI.val(), project = $('[name="projectPath"]').val();
            if(title == null || title == '' || project == null || project == '')
                bValid = false;
            if(!dueDate.isValid())
                bValid = false;
            if(rh.model.get(".d.versions.valid") === false){
                bValid = false;
            }
            bValid? create.removeClass(DISABLE_CLASS):create.addClass(DISABLE_CLASS);
        };
        titleUI.keyup(validateAll);
        var subs = false;
        projectUI.click(function(){
            if(!subs)
                projectUI.find(".coral-SelectList-item").click(function() {
                    if(clearAllUsers) clearAllUsers();
                    rh._.defer(validateAll);
                });
            subs = true;
        });

        dueDateUI.change(validateAll);
        return validateAll;
    };


    var checkAssigneeChange = (function(){
        var bInitAsignee = false, tagList = null, TAGLISTID = 'userTagList';
        var userList = null;

            return function() {
                var NULLVAL = "null";
                var assigneeField = $("input[name=assignee]");
                var assignee = assigneeField.val();

                if(!userList)
                    userList = $('.userlist');

                if(userList.find('[data-value]').length > 0)
                    for(var i=0;i<assigneeList.length;i++){
                        userList.find('[data-value="'+ assigneeList[i]+'"]').hide();
                    }

                if (assignee != null && assignee.length != 0 && assignee != NULLVAL)
                {
                    if(assigneeList.indexOf(assignee) != -1){
                        assigneeField.val("");
                        assigneeField.prev().val("");
                        return;
                    }
                    var USER_TAGLIST_TEMPLATE = '<ol class="coral-TagList" role="list" id="'+ TAGLISTID +'"  ></ol>';
                    var BUTTON_PARENT = "#aem-asset-reviewtask-assign";
                    var displayName = assigneeField.prev().val();
                    assigneeField.val("");
                    assigneeField.prev().val("");
                    if(!bInitAsignee) {
                        bInitAsignee = true;
                        $(BUTTON_PARENT).append($.parseHTML(USER_TAGLIST_TEMPLATE));
                         tagList = new CUI.TagList({ element:'#' +TAGLISTID, values:[] });
                        $('#'+ TAGLISTID).on('itemremoved', function(event, item) {
                            assigneeList = jQuery.grep(assigneeList, function(value) {
                              return value != item.value;
                            });
                            validateAll();
                        })
                    }
                    tagList.addItem( {'display': displayName, 'value': assignee} );
                    assigneeList.push(assignee);
                    if(!clearAllUsers){
                        clearAllUsers = function() {
                            assigneeList.forEach(function(item){
                                tagList.removeItem(item);
                            });
                            assigneeList = [];
                        };
                    }
                    validateAll();
                }
            }
    })();

    $(document).on("foundation-contentloaded" + createWizardRel, function(e) {
        if(!payloadExists &&  getParameterByName('taskID') === null ) {
            ui.alert(Granite.I18n.get("Payload not found"),
                "Payload value: " + JSON.stringify(payload) + ". Please go back and select file for review",
                "error");
        }
        if( getParameterByName('taskID') != null){
            var operation="GETREVIEWDATA";
            var targetURL = "/bin/publishlistener?operation="+ operation + "&taskId=" + getParameterByName('taskID');
            var ajaxOptions = {
                type: "get",
                url: targetURL,
                cache: false
            };
            var jqxhr = $.ajax(ajaxOptions);
            jqxhr.done(function(resultJson) {
                if(!resultJson['isDitamap']){
                    hideDitamapChooser()
                    payload = {asset: []}
                }
                else{
                    setDitamapPath(resultJson.ditamap)
                }

                publishOldData(resultJson)
                registerOnPage1Next()
            });

        }
        else{
            hideDitamapChooser()
            rh.model.publish(".d.versions.payload",payload);
        }

        initValidation();
        var $form = $(createWizardRel);
        setInterval(function() {
            checkAssigneeChange()
        }, 100);
        $form.submit(function(e){
            e.preventDefault();
        });

        $form.on("click",".version-next-button", function(e) {

            doNext($form)
        })

        $form.on("click",".version-review-button",function(e) {
            e.preventDefault();
            doSubmit($form);
        });
        $(TITLE_XPATH).focus();
    });

    $(document).on("foundation-contentloaded" + createWizardRel, function(e) {
        updateUserPickerSrc();
        var $form = $( createWizardRel);
        var $projectPathField = $("[name='projectPath']", $form);

        var $projectSelector = $projectPathField.closest(".coral-Select");
        $projectSelector.on("selected", function() {
            updateUserPickerSrc();

            var $assigneeSubmitField = $("input[name='assignee']", $form);

            // logged CUI-2304 .. the following lines should be replaced by
            //  $assigneeSubmitField.closest(".granite-autocomplete").data("autocomplete").clear()
            $assigneeSubmitField.val("");
            $assigneeSubmitField.siblings("input").val("");
            $assigneeSubmitField.closest(".granite-autocomplete").data("autocomplete")._lastSelected = "";
        });
    });

    function getParameterByName(name) {
        var url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

    function updateUserPickerSrc() {
        var $form = $(createWizardRel);
        // find the project path field
        var $projectPathField = $("[name='projectPath']", $form);
        var $cuiSelectList = $(".coral-Autocomplete .coral-SelectList", $form);
        var originalURL = $cuiSelectList.attr("data-task-original-url");
        var updatedURL = $cuiSelectList.attr("data-granite-autocomplete-src");
        if (originalURL === undefined || originalURL === "") {
            $cuiSelectList.attr("data-task-original-url", updatedURL);
            originalURL = updatedURL;
        }
        $cuiSelectList.attr("data-granite-autocomplete-src", originalURL + "&projectPath="+$projectPathField.val());
    }




})(Granite.$);
