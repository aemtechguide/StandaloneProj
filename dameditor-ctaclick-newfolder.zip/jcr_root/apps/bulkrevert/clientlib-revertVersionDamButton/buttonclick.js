(function (document, $) {
    "use strict";

    var CTA_DITA_ELEMENT_ID = "cta-dita-button";
	var CTA_BUTTON_CLASS = "initiate-cta";

    var CTA_PAYLOAD_KEY = {
        "revert": "fmdita.revert_data"
    }




    //On document-ready
    $(function() {

		//revert button clickk
        $("#" + CTA_DITA_ELEMENT_ID).click(function () {
            ctaclick();
        });




    });

	function ctaclick() {
        var topics = getFiles();
        var collabType = "revert";
        var redirectUrl = "/apps/bulkrevert/revert.html";
        redirect(redirectUrl, topics, collabType);    
    }

    function getFiles() {
        var topics = [];
        var selectedAsset =  $(".foundation-collection-item.foundation-selections-item");
        
        if (selectedAsset != null) {
            if(selectedAsset.length) {
                
                for(var i = 0; i < selectedAsset.length; i++) {
                    var path = $(selectedAsset[i]).attr("data-foundation-collection-item-id");;
                    var lpath = path.toLowerCase();
                    topics.push(path);                        
                }
            }
        }
        return topics;
    }

    function redirect(url, topics, collabType) {
        var respjson = null;
        topics.forEach(function(topic, index){
            if(!respjson)
                respjson = breakPath(topic);
            else
            {
                var tmpjson = breakPath(topic);
                if(tmpjson.asset.length)
                    respjson.asset[respjson.asset.length] = tmpjson.asset[0];
            }
        });
        respjson.referrer = document.URL;
        if (respjson && CTA_PAYLOAD_KEY[collabType]) {
            sessionStorage.setItem(CTA_PAYLOAD_KEY[collabType], window.encodeURIComponent(JSON.stringify(respjson)));
            window.location.href = url;
        }
    }

    function breakPath(path) {
        var idx = path.lastIndexOf("/");
        if(idx != -1)
            return {base : path.substring(0, idx), asset : [ path ]};
        else
            return {base : path, asset : []};
    };


})(document, Granite.$);
